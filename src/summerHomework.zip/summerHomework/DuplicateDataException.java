package summerHomework;

public class DuplicateDataException extends Exception {

	public DuplicateDataException() {
		super("Duplicate Data");
	}

}
