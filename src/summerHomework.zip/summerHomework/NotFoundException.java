package summerHomework;

public class NotFoundException extends Exception {

	public NotFoundException() {
		super("Not Found");
	}
}
