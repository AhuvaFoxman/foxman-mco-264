package schoolApp;

public class NotFoundException extends Exception{
	public NotFoundException(){
		super("not found");
	}

}
