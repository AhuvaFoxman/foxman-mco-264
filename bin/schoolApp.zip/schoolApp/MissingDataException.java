package schoolApp;

public class MissingDataException extends Exception{
	public MissingDataException(){
		super("missing data");
	}

}
