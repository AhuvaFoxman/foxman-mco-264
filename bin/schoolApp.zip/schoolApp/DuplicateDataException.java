package schoolApp;

public class DuplicateDataException extends Exception{
	
	public DuplicateDataException(){
		super("duplicate data");
	}

}
